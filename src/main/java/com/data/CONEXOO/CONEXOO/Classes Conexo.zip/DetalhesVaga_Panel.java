/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JPanel.java to edit this template
 */
package com.data.CONEXOO.CONEXOO;

/**
 *
 * @author liluis
 */
public class DetalhesVaga_Panel extends javax.swing.JPanel {
    private int idVaga;
    private int idUsuario;
    private Runnable acaoVoltarVagas;
    

public void setAcaoVoltarVagas(Runnable acao) {
    this.acaoVoltarVagas = acao;
}


private void curtirVaga() {

    String sql = "INSERT INTO interesses "
           + "(id_candidato, id_vaga, origem) "
           + "SELECT id_candidato, ?, 'candidato' "
           + "FROM candidatos WHERE id_usuario = ? "
           + "ON CONFLICT (id_candidato, id_vaga, origem) DO NOTHING";

    try (java.sql.Connection conexao = Conexao.conectar();
         java.sql.PreparedStatement stmt =
                 conexao.prepareStatement(sql)) {

        stmt.setInt(1, idVaga);
        stmt.setInt(2, idUsuario);

        int linhas = stmt.executeUpdate();

        if (linhas > 0) {
            javax.swing.JOptionPane.showMessageDialog(
                this, "Vaga curtida com sucesso!"
            );
            btnCandidatar.setText("♡ Vaga curtida");
        } else {
            javax.swing.JOptionPane.showMessageDialog(
                this, "Perfil de candidato não encontrado."
            );
        }

    } catch (java.sql.SQLException e) {
        javax.swing.JOptionPane.showMessageDialog(
            this, "Erro ao curtir vaga: " + e.getMessage()
        );
    }
}

private void verificarCurtida() {

    String sql = "SELECT 1 FROM interesses i "
               + "INNER JOIN candidatos c "
               + "ON i.id_candidato = c.id_candidato "
               + "WHERE c.id_usuario = ? "
               + "AND i.id_vaga = ? "
               + "AND i.origem = 'candidato'";

    try (java.sql.Connection conexao = Conexao.conectar();
         java.sql.PreparedStatement stmt =
                 conexao.prepareStatement(sql)) {

        stmt.setInt(1, idUsuario);
        stmt.setInt(2, idVaga);

        try (java.sql.ResultSet rs = stmt.executeQuery()) {
            if (rs.next()) {
                btnCandidatar.setText("♡ Vaga curtida");
            } else {
                btnCandidatar.setText("♡ Curtir vaga");
            }
        }

    } catch (java.sql.SQLException e) {
        javax.swing.JOptionPane.showMessageDialog(
            this, "Erro ao verificar curtida: " + e.getMessage()
        );
    }
}

private void descurtirVaga() {

    String sql = "DELETE FROM interesses i "
               + "USING candidatos c "
               + "WHERE i.id_candidato = c.id_candidato "
               + "AND c.id_usuario = ? "
               + "AND i.id_vaga = ? "
               + "AND i.origem = 'candidato'";

    try (java.sql.Connection conexao = Conexao.conectar();
         java.sql.PreparedStatement stmt =
                 conexao.prepareStatement(sql)) {

        stmt.setInt(1, idUsuario);
        stmt.setInt(2, idVaga);

        int linhas = stmt.executeUpdate();

        if (linhas > 0) {
            javax.swing.JOptionPane.showMessageDialog(
                this, "Curtida removida com sucesso!"
            );
            btnCandidatar.setText("♡ Curtir vaga");
        }
        else {
        javax.swing.JOptionPane.showMessageDialog(
        this, "Nenhuma curtida encontrada para remover."
    );
}
    } catch (java.sql.SQLException e) {
        javax.swing.JOptionPane.showMessageDialog(
            this, "Erro ao remover curtida: " + e.getMessage()
        );
    }
}


    /**
     * Creates new form DetalhesVaga_Panel
     */
    public DetalhesVaga_Panel() {
        initComponents();
    }
    public DetalhesVaga_Panel(int idVaga, int idUsuario) {
    initComponents();
    this.idVaga = idVaga;
    this.idUsuario = idUsuario;
    carregarDetalhesVaga();
    verificarCurtida();
}
    
private void carregarDetalhesVaga() {

    String sql = "SELECT v.*, e.nome_fantasia "
            + "FROM vagas v "
            + "INNER JOIN empresas e ON v.id_empresa = e.id_empresa "
            + "WHERE v.id_vaga = ?";

    try (java.sql.Connection conexao = Conexao.conectar();
         java.sql.PreparedStatement stmt =
                 conexao.prepareStatement(sql)) {

        stmt.setInt(1, idVaga);

        try (java.sql.ResultSet rs = stmt.executeQuery()) {

            if (rs.next()) {

                lblNomeVaga.setText(rs.getString("titulo"));
                lblNomeEmpresa.setText(rs.getString("nome_fantasia"));
                lblLocalizacao.setText(rs.getString("localizacao"));

                lblModalidade.setText(
                        "Modalidade: " + rs.getString("modelo_trabalho")
                );

                lblTipoContrato.setText(
                        "Contrato: " + rs.getString("tipo_contrato")
                );

                txtDescricaoDetalhes.setText(rs.getString("descricao"));
                txtDescricaoDetalhes.setCaretPosition(0);

                java.math.BigDecimal minimo =
                        rs.getBigDecimal("salario_min");

                java.math.BigDecimal maximo =
                        rs.getBigDecimal("salario_max");

                if (minimo != null && maximo != null) {
                    java.text.NumberFormat moeda =
                            java.text.NumberFormat.getCurrencyInstance(
                                    new java.util.Locale("pt", "BR")
                            );

                    lblSalario.setText(
                            moeda.format(minimo) + " até "
                            + moeda.format(maximo)
                    );
                } else {
                    lblSalario.setText("Salário a combinar");
                }

            } else {
                javax.swing.JOptionPane.showMessageDialog(
                        this, "Vaga não encontrada!"
                );
            }
        }

    } catch (java.sql.SQLException e) {
        javax.swing.JOptionPane.showMessageDialog(
                this,
                "Erro ao carregar detalhes da vaga: " + e.getMessage()
        );
    }
}


    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lblTituloDetalhes = new javax.swing.JLabel();
        lblSubtituloDetalhes = new javax.swing.JLabel();
        lblNomeVaga = new javax.swing.JLabel();
        lblNomeEmpresa = new javax.swing.JLabel();
        lblLocalizacao = new javax.swing.JLabel();
        lblSalario = new javax.swing.JLabel();
        lblModalidade = new javax.swing.JLabel();
        lblTipoContrato = new javax.swing.JLabel();
        lblTituloDescricao = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        txtDescricaoDetalhes = new javax.swing.JTextArea();
        btnVoltarVagas = new javax.swing.JButton();
        btnCandidatar = new javax.swing.JButton();

        setBackground(new java.awt.Color(11, 25, 48));
        setBorder(javax.swing.BorderFactory.createMatteBorder(2, 2, 2, 2, new java.awt.Color(19, 216, 245)));

        lblTituloDetalhes.setFont(new java.awt.Font("Segoe UI", 1, 26)); // NOI18N
        lblTituloDetalhes.setForeground(new java.awt.Color(255, 255, 255));
        lblTituloDetalhes.setText("Detalhes da Vaga");

        lblSubtituloDetalhes.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblSubtituloDetalhes.setForeground(new java.awt.Color(148, 163, 184));
        lblSubtituloDetalhes.setText("Confira todas as informações desta oportunidade.");

        lblNomeVaga.setFont(new java.awt.Font("Segoe UI", 1, 22)); // NOI18N
        lblNomeVaga.setForeground(new java.awt.Color(255, 255, 255));
        lblNomeVaga.setText("Título da vaga");

        lblNomeEmpresa.setFont(new java.awt.Font("Segoe UI", 0, 15)); // NOI18N
        lblNomeEmpresa.setForeground(new java.awt.Color(148, 163, 184));
        lblNomeEmpresa.setText("Nome da empresa");

        lblLocalizacao.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblLocalizacao.setForeground(new java.awt.Color(148, 163, 184));
        lblLocalizacao.setText("Localização");

        lblSalario.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        lblSalario.setForeground(new java.awt.Color(56, 189, 248));
        lblSalario.setText("Salário");

        lblModalidade.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblModalidade.setForeground(new java.awt.Color(148, 163, 184));
        lblModalidade.setText("Modalidade: Remoto");

        lblTipoContrato.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblTipoContrato.setForeground(new java.awt.Color(148, 163, 184));
        lblTipoContrato.setText("Contrato: CLT");

        lblTituloDescricao.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        lblTituloDescricao.setForeground(new java.awt.Color(255, 255, 255));
        lblTituloDescricao.setText("Descrição da Vaga");

        jScrollPane1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(8, 127, 167)));

        txtDescricaoDetalhes.setEditable(false);
        txtDescricaoDetalhes.setBackground(new java.awt.Color(16, 39, 71));
        txtDescricaoDetalhes.setColumns(20);
        txtDescricaoDetalhes.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        txtDescricaoDetalhes.setForeground(new java.awt.Color(255, 255, 255));
        txtDescricaoDetalhes.setLineWrap(true);
        txtDescricaoDetalhes.setRows(5);
        txtDescricaoDetalhes.setWrapStyleWord(true);
        txtDescricaoDetalhes.setBorder(null);
        jScrollPane1.setViewportView(txtDescricaoDetalhes);

        btnVoltarVagas.setBackground(new java.awt.Color(25, 55, 85));
        btnVoltarVagas.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnVoltarVagas.setForeground(new java.awt.Color(255, 255, 255));
        btnVoltarVagas.setText("Voltar para Vagas");
        btnVoltarVagas.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(8, 127, 167)));
        btnVoltarVagas.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnVoltarVagas.addActionListener(this::btnVoltarVagasActionPerformed);

        btnCandidatar.setBackground(new java.awt.Color(6, 182, 212));
        btnCandidatar.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnCandidatar.setText("Candidatar-se");
        btnCandidatar.addActionListener(this::btnCandidatarActionPerformed);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(450, 450, 450)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblTituloDetalhes)
                    .addComponent(lblSubtituloDetalhes)
                    .addComponent(lblNomeVaga)
                    .addComponent(lblNomeEmpresa)
                    .addComponent(lblLocalizacao)
                    .addComponent(lblSalario)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(lblModalidade)
                        .addGap(18, 18, 18)
                        .addComponent(lblTipoContrato))
                    .addComponent(lblTituloDescricao)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addComponent(btnVoltarVagas, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnCandidatar, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 300, Short.MAX_VALUE)))
                .addContainerGap(908, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(150, 150, 150)
                .addComponent(lblTituloDetalhes)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblSubtituloDetalhes)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblNomeVaga)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblNomeEmpresa)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblLocalizacao)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblSalario)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblModalidade)
                    .addComponent(lblTipoContrato))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblTituloDescricao)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(8, 8, 8)
                .addComponent(btnCandidatar, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnVoltarVagas, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(275, Short.MAX_VALUE))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void btnVoltarVagasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVoltarVagasActionPerformed
        if (acaoVoltarVagas != null) {
        acaoVoltarVagas.run();
    }     
    }//GEN-LAST:event_btnVoltarVagasActionPerformed

    private void btnCandidatarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCandidatarActionPerformed
        if (btnCandidatar.getText().contains("Vaga curtida")) {
        descurtirVaga();
    } else {
        curtirVaga();
    }//GEN-LAST:event_btnCandidatarActionPerformed
    }
        public void definirTextoVoltar(boolean veioDeInteresses) {
    if (veioDeInteresses) {
        btnVoltarVagas.setText("← Voltar para Interesses");
    } else {
        btnVoltarVagas.setText("← Voltar para Vagas");
    }
}
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCandidatar;
    private javax.swing.JButton btnVoltarVagas;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lblLocalizacao;
    private javax.swing.JLabel lblModalidade;
    private javax.swing.JLabel lblNomeEmpresa;
    private javax.swing.JLabel lblNomeVaga;
    private javax.swing.JLabel lblSalario;
    private javax.swing.JLabel lblSubtituloDetalhes;
    private javax.swing.JLabel lblTipoContrato;
    private javax.swing.JLabel lblTituloDescricao;
    private javax.swing.JLabel lblTituloDetalhes;
    private javax.swing.JTextArea txtDescricaoDetalhes;
    // End of variables declaration//GEN-END:variables
}
